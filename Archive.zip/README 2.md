# weather-report

This project is generated with [yo angular generator] 

## Build & development

Run `grunt` for building and `grunt serve` for preview.

## Testing

Running `grunt test` will run the unit tests with karma.

Additional e2e test is will run with protractor.



Please make sure you shoud having jdk installed in your system

1. Start the Selenium server:
./node_modules/.bin/webdriver-manager start

2. Open a new terminal and run Protractor:
./node_modules/.bin/protractor protractor.conf.js


npm install 

grunt serve

grunt test ( for all test together)

grunt runOnlyKarmaTest

grunt runOnlyProtractorTest


